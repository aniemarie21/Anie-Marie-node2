const print = {
    app: (req, res) => {
        res.render('home');
    }
    //app: (req, res) => {
       //res.render("app")
    //}
};

module.exports = print;