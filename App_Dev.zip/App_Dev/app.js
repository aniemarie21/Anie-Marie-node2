const express = require('express');
const routes = require('./routes/router');
const body_parser = require('body-parser');
const app = express();


const PORT = 3001;

app.set('view engine', 'ejs');
app.use(body_parser.urlencoded({extended:true}));
app.use('/', routes);
app.use(express.static('public'))

//Run
app.listen(PORT, () => {
    console.log(`Connected successfully! Server is running on http://localhost:${PORT}/`);
})
