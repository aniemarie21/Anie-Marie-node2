const express = require('express');
const router =  express.Router();
const dev = require('../Controller/UserController');


router.get('/', dev.app);
//router.get('/app', controller.app)

module.exports = router;